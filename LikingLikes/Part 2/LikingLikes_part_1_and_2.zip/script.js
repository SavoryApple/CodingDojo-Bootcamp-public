var likeSum = 1;
function buttonClick(){
    
    var likeNumb = document.querySelector("#numbLikes1");
    likeNumb.innerText = likeSum + " Like(s)";
    likeSum += 1;
}
var likeSum2 = 1;
function buttonClick2(){
    var likeNumb = document.querySelector("#numbLikes2");
    likeNumb.innerText = likeSum2 + " Like(s)";
    likeSum2 += 1;
}
var likeSum3 = 1;
function buttonClick3(){
    var likeNumb = document.querySelector("#numbLikes3");
    likeNumb.innerText = likeSum3 + " Like(s)";
    likeSum3 += 1;
}